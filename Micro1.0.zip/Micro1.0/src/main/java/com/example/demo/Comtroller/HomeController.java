package com.example.demo.Comtroller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.example.demo.Model.UserDetail;
import com.example.demo.Repository.UserRepository;


@Controller
@SessionAttributes("userDetail")
public class HomeController {
	
	
	
	HttpSession session;
	HttpServletRequest request;
	Model model;
	
	
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	UserDetail userDetail;
	
	@Autowired
    protected MongoTemplate mongoTemplate;
	
	@RequestMapping("/")
	public String showHome()
	{
		return "Home";
		
	}
	
	
	@RequestMapping("/Login")
	public String showLoginForm()
	{
		return "Login";
		
	}

		
	@PostMapping("/destroy")
	public String destroySession() {
		request.getSession().invalidate();
		return "redirect:/";
	}
	
	

	
	@RequestMapping("/UserRole")
	public String userrole()
	{
			
		return "UserRole";
	}
	
	
	@RequestMapping("/checkLogin")
	
	public String checkLogin(@RequestParam("Username") String Username, @RequestParam("Password") String Password)
	{
		
		userDetail=userRepository.findByUsername(Username);
		if(userDetail!=null)
		{
			
			if(userDetail.getPassword().equals(Password))
			{
				System.out.println("Right Username And Password");
				
				return "User";
			}
			
			else
			{
				
				Query query = new Query();
				query.addCriteria(Criteria.where("username").is(Username));
				Update update = new Update();
				update.set("unsuccessfulAttempts", userDetail.getUnsuccessfulAttempts()+1);
				mongoTemplate.updateFirst(query, update, UserDetail.class);
				
				System.out.print("Incorrect Password");
				return "Login";
				
				
			}
			
		}
		
		else
		{
			System.out.println("No User With This Username Exists");
			return "Login";
		}
		
		
		
		

		
	}
	
	
	@GetMapping("/access-denied")
	public String showAccessDenied() {
		
		return "Access-Denied";
		
	}


}
