package com.example.demo.Model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Document(collection="UserDetail")
public class UserDetail {
	
	
	private String username;
	private String password;
	private int unsuccessfulAttempts;
	private String accountStatus;
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getUnsuccessfulAttempts() {
		return unsuccessfulAttempts;
	}
	public void setUnsuccessfulAttempts(int unsuccessfulAttempts) {
		this.unsuccessfulAttempts = unsuccessfulAttempts;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	@Override
	public String toString() {
		return "UserDetail [username=" + username + ", password=" + password + ", unsuccessfulAttempts="
				+ unsuccessfulAttempts + ", accountStatus=" + accountStatus + "]";
	}
	
	

	
	
	

}
