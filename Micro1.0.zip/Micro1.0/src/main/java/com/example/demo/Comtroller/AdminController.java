package com.example.demo.Comtroller;

public class AdminController {

}
